# HRIS System

## Overview

This is a comprehensive Human Resources Information System (HRIS) built with React, TypeScript, Express.js, and PostgreSQL. The system provides real-time HR operations management including employee profiles, document management, performance tracking, leave management, time & attendance, and recruitment processes. The application features role-based access control (Employee, HR, Admin) with secure authentication and a modern, responsive interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development patterns
- **Styling**: TailwindCSS with Shadcn/ui components for consistent design system
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Animations**: Framer Motion for smooth UI transitions and interactions
- **Theming**: Custom theme provider supporting light/dark modes with CSS custom properties

### Backend Architecture  
- **Server Framework**: Express.js with TypeScript running in ESM mode
- **Database ORM**: Drizzle ORM for type-safe database interactions
- **API Design**: RESTful API endpoints with standardized error handling
- **File Structure**: Modular architecture with separate route handlers and storage abstraction
- **Development Setup**: Vite integration for hot module replacement during development

### Authentication & Authorization
- **Authentication Provider**: Replit's OIDC authentication system
- **Session Management**: Express sessions with PostgreSQL store using connect-pg-simple
- **Access Control**: Role-based permissions (Employee, HR, Admin) with route-level protection
- **Security**: Parameterized queries, input validation, and secure session handling

### Database Design
- **Primary Database**: PostgreSQL with Neon serverless connection
- **Schema Management**: Drizzle migrations with proper foreign key relationships
- **Core Tables**: Users, employees, documents, performance records, leave requests, attendance records, candidates
- **Session Storage**: Dedicated sessions table for authentication state persistence
- **Data Validation**: Zod schemas for runtime type checking and API validation

### UI Component System
- **Component Library**: Radix UI primitives with custom styling
- **Design System**: Consistent color palette, typography, and spacing using CSS custom properties
- **Responsive Design**: Mobile-first approach with responsive breakpoints
- **Accessibility**: Built-in accessibility features from Radix UI components
- **Charts & Visualization**: Recharts integration for dashboard analytics and performance metrics

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: PostgreSQL serverless database connection
- **drizzle-orm**: Type-safe database ORM with PostgreSQL adapter
- **@tanstack/react-query**: Server state management and data fetching
- **express**: Web application framework for API server
- **@radix-ui/***: Accessible UI component primitives

### Authentication & Security
- **openid-client**: OpenID Connect authentication with Passport.js strategy
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **express-session**: Session middleware for user authentication state

### Development & Build Tools
- **vite**: Development server and build tool with React plugin
- **tsx**: TypeScript execution for development server
- **esbuild**: Fast bundling for production server build
- **tailwindcss**: Utility-first CSS framework for styling

### UI & Visualization
- **recharts**: Chart library for dashboard analytics and data visualization
- **framer-motion**: Animation library for smooth UI transitions
- **lucide-react**: Icon library with React components
- **class-variance-authority**: Utility for component variant styling