import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Megaphone, 
  GraduationCap, 
  CheckCircle, 
  FileText, 
  Calendar,
  Clock,
  UserCheck,
  Upload
} from "lucide-react";

export default function RecentActivity() {
  const announcements = [
    {
      id: 1,
      title: "Holiday Notice",
      description: "Office will be closed on December 25th for Christmas celebration.",
      time: "2 hours ago",
      icon: Megaphone,
      iconBg: "bg-accent",
      iconColor: "text-accent-foreground",
    },
    {
      id: 2,
      title: "Training Program",
      description: "New employee onboarding session scheduled for next Monday.",
      time: "5 hours ago",
      icon: GraduationCap,
      iconBg: "bg-blue-500",
      iconColor: "text-white",
    },
    {
      id: 3,
      title: "Performance Reviews",
      description: "Q4 performance review cycle begins next week. Please prepare your self-assessments.",
      time: "1 day ago",
      icon: FileText,
      iconBg: "bg-green-500",
      iconColor: "text-white",
    },
  ];

  const recentActivities = [
    {
      id: 1,
      user: "John Smith",
      action: "checked in",
      department: "Engineering Department",
      time: "9:15 AM",
      icon: UserCheck,
      iconBg: "bg-green-100 dark:bg-green-900/20",
      iconColor: "text-green-600",
    },
    {
      id: 2,
      user: "Sarah Wilson",
      action: "uploaded KPI report",
      department: "Marketing Department",
      time: "8:45 AM",
      icon: Upload,
      iconBg: "bg-blue-100 dark:bg-blue-900/20",
      iconColor: "text-blue-600",
    },
    {
      id: 3,
      user: "Mike Johnson",
      action: "requested leave",
      department: "Sales Department",
      time: "8:30 AM",
      icon: Calendar,
      iconBg: "bg-yellow-100 dark:bg-yellow-900/20",
      iconColor: "text-yellow-600",
    },
    {
      id: 4,
      user: "Emily Brown",
      action: "completed training",
      department: "HR Department",
      time: "8:15 AM",
      icon: CheckCircle,
      iconBg: "bg-purple-100 dark:bg-purple-900/20",
      iconColor: "text-purple-600",
    },
    {
      id: 5,
      user: "David Lee",
      action: "submitted timesheet",
      department: "Finance Department",
      time: "8:00 AM",
      icon: Clock,
      iconBg: "bg-orange-100 dark:bg-orange-900/20",
      iconColor: "text-orange-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Recent Announcements</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {announcements.map((announcement, index) => (
              <motion.div
                key={announcement.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.2 + index * 0.1 }}
                className="flex items-start p-4 bg-muted/50 dark:bg-muted/30 rounded-lg hover:bg-muted/70 dark:hover:bg-muted/50 transition-colors"
                data-testid={`announcement-${announcement.id}`}
              >
                <div className={`w-10 h-10 ${announcement.iconBg} rounded-full flex items-center justify-center mr-3 flex-shrink-0`}>
                  <announcement.icon className={`h-5 w-5 ${announcement.iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-foreground">{announcement.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {announcement.description}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2 flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {announcement.time}
                  </p>
                </div>
              </motion.div>
            ))}
          </CardContent>
        </Card>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentActivities.map((activity, index) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.3 + index * 0.05 }}
                className="flex items-center justify-between py-2 border-b border-border last:border-b-0 hover:bg-muted/30 dark:hover:bg-muted/20 rounded px-2 transition-colors"
                data-testid={`activity-${activity.id}`}
              >
                <div className="flex items-center flex-1 min-w-0">
                  <div className={`w-8 h-8 ${activity.iconBg} rounded-full flex items-center justify-center mr-3 flex-shrink-0`}>
                    <activity.icon className={`h-4 w-4 ${activity.iconColor}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">
                      <span className="font-semibold">{activity.user}</span> {activity.action}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {activity.department}
                    </p>
                  </div>
                </div>
                <Badge variant="outline" className="text-xs font-normal ml-2">
                  {activity.time}
                </Badge>
              </motion.div>
            ))}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
