import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import { Users, Calendar, Trophy, ClipboardList, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";

export default function MetricsCards() {
  const { toast } = useToast();
  
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  const metricsData = [
    {
      title: "Total Employees",
      value: (metrics as any)?.totalEmployees || 0,
      trend: "+12% this month",
      trendIcon: TrendingUp,
      trendColor: "text-green-600",
      icon: Users,
      iconBg: "bg-blue-100 dark:bg-blue-900/20",
      iconColor: "text-blue-600",
    },
    {
      title: "Active Leaves",
      value: (metrics as any)?.activeLeaves || 0,
      trend: "5 pending approval",
      trendIcon: AlertTriangle,
      trendColor: "text-yellow-600",
      icon: Calendar,
      iconBg: "bg-yellow-100 dark:bg-yellow-900/20",
      iconColor: "text-yellow-600",
    },
    {
      title: "Top Performers",
      value: (metrics as any)?.topPerformers || 0,
      trend: "KPI ≥ 60%",
      trendIcon: TrendingUp,
      trendColor: "text-green-600",
      icon: Trophy,
      iconBg: "bg-green-100 dark:bg-green-900/20",
      iconColor: "text-green-600",
    },
    {
      title: "Pending Requests",
      value: (metrics as any)?.pendingRequests || 0,
      trend: "Needs attention",
      trendIcon: AlertTriangle,
      trendColor: "text-red-600",
      icon: ClipboardList,
      iconBg: "bg-red-100 dark:bg-red-900/20",
      iconColor: "text-red-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metricsData.map((metric, index) => (
        <motion.div
          key={metric.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Card className="metric-card transition-all duration-300 hover:shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    {metric.title}
                  </p>
                  <motion.p
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 + 0.2 }}
                    className="text-3xl font-bold mt-1"
                    data-testid={`metric-${metric.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {isLoading ? (
                      <span className="animate-pulse">--</span>
                    ) : (
                      metric.value
                    )}
                  </motion.p>
                  <p className={`text-sm mt-1 flex items-center ${metric.trendColor}`}>
                    <metric.trendIcon className="h-3 w-3 mr-1" />
                    {metric.trend}
                  </p>
                </div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                  className={`w-12 h-12 ${metric.iconBg} rounded-lg flex items-center justify-center`}
                >
                  <metric.icon className={`h-6 w-6 ${metric.iconColor}`} />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
