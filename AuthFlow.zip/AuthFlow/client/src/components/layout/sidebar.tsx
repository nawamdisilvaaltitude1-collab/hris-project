import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { Link, useLocation } from "wouter";
import { useTheme } from "@/components/ui/theme-provider";
import { 
  Building, 
  Moon, 
  Sun, 
  BarChart3, 
  Users, 
  FileText, 
  Trophy, 
  Calendar, 
  Clock, 
  UserPlus,
  LogOut
} from "lucide-react";

export default function Sidebar() {
  const { user } = useAuth();
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  const menuItems = [
    { path: "/", icon: BarChart3, label: "Dashboard" },
    { path: "/employees", icon: Users, label: "Employees" },
    { path: "/documents", icon: FileText, label: "Documents" },
    { path: "/performance", icon: Trophy, label: "Performance" },
    { path: "/leave", icon: Calendar, label: "Leave Management" },
    { path: "/attendance", icon: Clock, label: "Attendance" },
    { path: "/recruitment", icon: UserPlus, label: "Recruitment" },
  ];

  const isActive = (path: string) => {
    if (path === "/") return location === "/";
    return location.startsWith(path);
  };

  return (
    <motion.aside
      initial={{ x: -250 }}
      animate={{ x: 0 }}
      transition={{ duration: 0.3 }}
      className="w-64 bg-sidebar border-r border-sidebar-border min-h-screen p-4 flex flex-col"
    >
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="flex items-center mb-8"
      >
        <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center mr-3">
          <Building className="h-6 w-6 text-accent-foreground" />
        </div>
        <div>
          <h2 className="font-bold text-lg text-sidebar-foreground">HRIS</h2>
          <p className="text-xs text-sidebar-foreground/70">HR Management</p>
        </div>
      </motion.div>
      
      <Button
        variant="ghost"
        className="w-full mb-6 justify-start text-sidebar-foreground hover:bg-sidebar-accent"
        onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        data-testid="button-theme-toggle"
      >
        {theme === "dark" ? (
          <Sun className="mr-2 h-4 w-4" />
        ) : (
          <Moon className="mr-2 h-4 w-4" />
        )}
        <span>{theme === "dark" ? "Light Mode" : "Dark Mode"}</span>
      </Button>
      
      <nav className="space-y-2 flex-1">
        {menuItems.map((item, index) => (
          <motion.div
            key={item.path}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.1 + index * 0.05 }}
          >
            <Link href={item.path}>
              <Button
                variant="ghost"
                className={`sidebar-item w-full justify-start ${
                  isActive(item.path)
                    ? "bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                }`}
                data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <item.icon className="mr-3 h-4 w-4" />
                {item.label}
              </Button>
            </Link>
          </motion.div>
        ))}
      </nav>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="border-t border-sidebar-border pt-4"
      >
        <div className="flex items-center mb-2">
          <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center mr-2">
            <span className="text-sm font-bold text-accent-foreground">
              {(user as any)?.firstName?.[0] || (user as any)?.email?.[0] || 'U'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-foreground truncate">
              {(user as any)?.firstName && (user as any)?.lastName 
                ? `${(user as any).firstName} ${(user as any).lastName}`
                : (user as any)?.email || 'User'
              }
            </p>
            <p className="text-xs text-sidebar-foreground/70 capitalize">
              {(user as any)?.role || 'Employee'}
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent text-sm"
          onClick={() => window.location.href = '/api/logout'}
          data-testid="button-logout"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </motion.div>
    </motion.aside>
  );
}
