import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Bell } from "lucide-react";
import { useLocation } from "wouter";

export default function Header() {
  const [location] = useLocation();

  const getPageInfo = (path: string) => {
    switch (path) {
      case "/":
        return { title: "Dashboard", subtitle: "Real-time HR metrics and insights" };
      case "/employees":
        return { title: "Employee Management", subtitle: "Manage employee profiles and information" };
      case "/documents":
        return { title: "Document Management", subtitle: "Upload and track employee documents" };
      case "/performance":
        return { title: "Performance Management", subtitle: "Track KPI scores and evaluations" };
      case "/leave":
        return { title: "Leave Management", subtitle: "Manage leave requests and approvals" };
      case "/attendance":
        return { title: "Time & Attendance", subtitle: "Track employee check-ins and hours" };
      case "/recruitment":
        return { title: "Recruitment Management", subtitle: "Manage candidates and hiring process" };
      default:
        return { title: "HRIS", subtitle: "Human Resources Information System" };
    }
  };

  const { title, subtitle } = getPageInfo(location);

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-between mb-8"
    >
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <h1 className="text-3xl font-bold text-foreground" data-testid="page-title">
          {title}
        </h1>
        <p className="text-muted-foreground mt-1" data-testid="page-subtitle">
          {subtitle}
        </p>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="flex items-center space-x-4"
      >
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search..."
            className="pl-10 pr-4 py-2 w-64 bg-background border-border focus:ring-2 focus:ring-ring focus:border-transparent"
            data-testid="input-search"
          />
        </div>
        
        <Button
          variant="ghost"
          size="icon"
          className="relative text-muted-foreground hover:text-foreground transition-colors"
          data-testid="button-notifications"
        >
          <Bell className="h-5 w-5" />
          <Badge
            variant="destructive"
            className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
          >
            3
          </Badge>
        </Button>
      </motion.div>
    </motion.header>
  );
}
