import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Clock, LogIn, LogOut, Users, Calendar, TrendingUp } from "lucide-react";

export default function Attendance() {
  const [currentTime, setCurrentTime] = useState(new Date());
  
  const { data: attendanceRecords = [], isLoading } = useQuery({
    queryKey: ["/api/attendance"],
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'late':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'absent':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'half_day':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const mockTopContributors = [
    { name: 'John Smith', initials: 'JS', hours: 47, color: 'bg-accent' },
    { name: 'Sarah Wilson', initials: 'SW', hours: 45, color: 'bg-blue-500' },
    { name: 'Mike Johnson', initials: 'MJ', hours: 43, color: 'bg-green-500' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <div className="text-4xl font-bold mb-2" data-testid="text-current-time">
                    {currentTime.toLocaleTimeString('en-US', {
                      hour12: true,
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit'
                    })}
                  </div>
                  <p className="text-muted-foreground">
                    {currentTime.toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <Button 
                    size="lg" 
                    className="bg-green-500 hover:bg-green-600 text-white py-6"
                    data-testid="button-check-in"
                  >
                    <LogIn className="h-6 w-6 mb-2" />
                    <div>
                      <p className="font-medium">Check In</p>
                      <p className="text-sm opacity-80">Last: 09:00 AM</p>
                    </div>
                  </Button>
                  <Button 
                    size="lg" 
                    variant="destructive" 
                    className="py-6"
                    data-testid="button-check-out"
                  >
                    <LogOut className="h-6 w-6 mb-2" />
                    <div>
                      <p className="font-medium">Check Out</p>
                      <p className="text-sm opacity-80">Expected: 06:00 PM</p>
                    </div>
                  </Button>
                </div>
                
                <div className="border-t border-border pt-6">
                  <h4 className="font-semibold mb-4">Today's Summary</h4>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: 0.2 }}
                      className="p-3 bg-muted rounded-lg"
                    >
                      <p className="text-2xl font-bold" data-testid="text-hours-worked">8h 45m</p>
                      <p className="text-sm text-muted-foreground">Hours Worked</p>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: 0.3 }}
                      className="p-3 bg-muted rounded-lg"
                    >
                      <p className="text-2xl font-bold" data-testid="text-break-time">45m</p>
                      <p className="text-sm text-muted-foreground">Break Time</p>
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: 0.4 }}
                      className="p-3 bg-muted rounded-lg"
                    >
                      <p className="text-2xl font-bold" data-testid="text-overtime">15m</p>
                      <p className="text-sm text-muted-foreground">Overtime</p>
                    </motion.div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
        
        <div className="space-y-6">
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Weekly Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">This Week</span>
                  <span className="font-bold" data-testid="text-weekly-hours">42h 30m</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: "85%" }}
                    transition={{ duration: 1, delay: 0.5 }}
                    className="bg-green-500 h-2 rounded-full"
                  ></motion.div>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0h</span>
                  <span>50h</span>
                </div>
                
                <div className="pt-4 border-t border-border">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Days Present</span>
                      <span className="font-medium" data-testid="text-days-present">4/5</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Avg. Daily Hours</span>
                      <span className="font-medium" data-testid="text-avg-hours">8h 30m</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Punctuality</span>
                      <span className="font-medium text-green-600" data-testid="text-punctuality">95%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Top Contributors</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {mockTopContributors.map((contributor, index) => (
                  <motion.div
                    key={contributor.name}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: 0.4 + index * 0.1 }}
                    className="flex items-center justify-between"
                    data-testid={`contributor-${index}`}
                  >
                    <div className="flex items-center">
                      <div className={`w-8 h-8 ${contributor.color} rounded-full flex items-center justify-center mr-3`}>
                        <span className="text-xs font-bold text-white">{contributor.initials}</span>
                      </div>
                      <span className="text-sm">{contributor.name}</span>
                    </div>
                    <span className="text-sm font-medium">{contributor.hours}h</span>
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Attendance History</CardTitle>
            <div className="flex items-center space-x-4">
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Employees" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Employees</SelectItem>
                  <SelectItem value="my">My Records</SelectItem>
                  <SelectItem value="department">Department</SelectItem>
                </SelectContent>
              </Select>
              <Input 
                type="month" 
                className="w-40" 
                defaultValue="2023-12"
                data-testid="input-filter-month"
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Check In</TableHead>
                    <TableHead>Check Out</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="animate-pulse">Loading attendance records...</div>
                      </TableCell>
                    </TableRow>
                  ) : attendanceRecords.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="flex flex-col items-center">
                          <Clock className="h-12 w-12 text-muted-foreground mb-4" />
                          <p className="text-muted-foreground">No attendance records found</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    attendanceRecords.map((record: any, index: number) => (
                      <motion.tr
                        key={record.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="hover:bg-muted/50 transition-colors"
                      >
                        <TableCell>
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center mr-3">
                              <Users className="h-5 w-5 text-accent-foreground" />
                            </div>
                            <div>
                              <p className="font-medium">Employee {record.employeeId}</p>
                              <p className="text-sm text-muted-foreground">Department</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{new Date(record.date).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <span className="text-green-600 font-medium">
                            {record.checkIn ? new Date(record.checkIn).toLocaleTimeString() : '-'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-red-600 font-medium">
                            {record.checkOut ? new Date(record.checkOut).toLocaleTimeString() : '-'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="font-medium">
                            {record.hoursWorked ? `${record.hoursWorked}h` : '0h'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(record.status)}>
                            {record.status === 'present' && <TrendingUp className="h-3 w-3 mr-1" />}
                            {record.status === 'late' && <Clock className="h-3 w-3 mr-1" />}
                            <span className="capitalize">{record.status}</span>
                          </Badge>
                        </TableCell>
                      </motion.tr>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
