import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { Trophy, TrendingUp, TrendingDown, Plus, Keyboard, FileSpreadsheet, Target, Users } from "lucide-react";

export default function Performance() {
  const { data: performanceRecords = [], isLoading } = useQuery({
    queryKey: ["/api/performance"],
  });

  const performanceStats = {
    topPerformers: performanceRecords.filter(record => parseFloat(record.kpiScore) >= 60).length,
    needsImprovement: performanceRecords.filter(record => parseFloat(record.kpiScore) < 60).length,
    averageScore: performanceRecords.length > 0 
      ? performanceRecords.reduce((sum, record) => sum + parseFloat(record.kpiScore), 0) / performanceRecords.length 
      : 0,
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-blue-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getCategoryColor = (category: string) => {
    return category === 'performer' 
      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
      : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Upload KPI Scores</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-4">
                <Button variant="outline" className="flex-1" data-testid="button-manual-entry">
                  <Keyboard className="mr-2 h-4 w-4" />
                  Manual Entry
                </Button>
                <Button variant="outline" className="flex-1" data-testid="button-csv-upload">
                  <FileSpreadsheet className="mr-2 h-4 w-4" />
                  CSV Upload
                </Button>
              </div>
              
              <div className="border border-border rounded-lg p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Employee</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select Employee" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="emp1">John Smith</SelectItem>
                        <SelectItem value="emp2">Sarah Wilson</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Month</label>
                    <Input type="month" data-testid="input-performance-month" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">KPI Score (%)</label>
                    <Input 
                      type="number" 
                      min="0" 
                      max="100" 
                      placeholder="85" 
                      data-testid="input-kpi-score"
                    />
                  </div>
                  <div className="flex items-end">
                    <Button className="w-full" data-testid="button-add-score">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Score
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-green-800 dark:text-green-300">Top Performers</p>
                  <p className="text-2xl font-bold text-green-900 dark:text-green-100">{performanceStats.topPerformers}</p>
                  <p className="text-xs text-green-600 dark:text-green-400">KPI ≥ 60%</p>
                </div>
                <div className="text-right">
                  <Trophy className="h-8 w-8 text-green-600 mb-1" />
                  <p className="text-xs text-green-600 dark:text-green-400">
                    {performanceRecords.length > 0 
                      ? Math.round((performanceStats.topPerformers / performanceRecords.length) * 100)
                      : 0}% of total
                  </p>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">Needs Improvement</p>
                  <p className="text-2xl font-bold text-yellow-900 dark:text-yellow-100">{performanceStats.needsImprovement}</p>
                  <p className="text-xs text-yellow-600 dark:text-yellow-400">KPI &lt; 60%</p>
                </div>
                <div className="text-right">
                  <TrendingUp className="h-8 w-8 text-yellow-600 mb-1" />
                  <p className="text-xs text-yellow-600 dark:text-yellow-400">
                    {performanceRecords.length > 0 
                      ? Math.round((performanceStats.needsImprovement / performanceRecords.length) * 100)
                      : 0}% of total
                  </p>
                </div>
              </div>
              
              <div className="border border-border rounded-lg p-4">
                <p className="text-sm font-medium mb-2">Average KPI Score</p>
                <div className="flex items-center">
                  <div className="flex-1 bg-muted rounded-full h-3 mr-3">
                    <div 
                      className="bg-accent h-3 rounded-full transition-all duration-500" 
                      style={{ width: `${performanceStats.averageScore}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-bold">{Math.round(performanceStats.averageScore)}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Performance Tracking</CardTitle>
            <div className="flex items-center space-x-4">
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="engineering">Engineering</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="sales">Sales</SelectItem>
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Last 6 Months" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="6m">Last 6 Months</SelectItem>
                  <SelectItem value="3m">Last 3 Months</SelectItem>
                  <SelectItem value="1y">This Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Current KPI</TableHead>
                    <TableHead>Trend</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Last Updated</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="animate-pulse">Loading performance data...</div>
                      </TableCell>
                    </TableRow>
                  ) : performanceRecords.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="flex flex-col items-center">
                          <Target className="h-12 w-12 text-muted-foreground mb-4" />
                          <p className="text-muted-foreground">No performance records found</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    performanceRecords.map((record: any, index: number) => (
                      <motion.tr
                        key={record.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="hover:bg-muted/50 transition-colors"
                      >
                        <TableCell>
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center mr-3">
                              <Users className="h-5 w-5 text-accent-foreground" />
                            </div>
                            <div>
                              <p className="font-medium">Employee {record.employeeId}</p>
                              <p className="text-sm text-muted-foreground">Department</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <span className="text-lg font-bold mr-2">{record.kpiScore}%</span>
                            <div className="w-16 bg-muted rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${getScoreColor(parseFloat(record.kpiScore))}`}
                                style={{ width: `${record.kpiScore}%` }}
                              ></div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-green-600 flex items-center">
                            <TrendingUp className="h-4 w-4 mr-1" />
                            +5%
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge className={getCategoryColor(record.category)}>
                            {record.category === 'performer' ? 'Performer' : 'Needs Improvement'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {record.updatedAt ? new Date(record.updatedAt).toLocaleDateString() : 'N/A'}
                        </TableCell>
                        <TableCell>
                          <Button size="sm" variant="outline" data-testid={`button-view-trend-${record.id}`}>
                            <TrendingUp className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </motion.tr>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
