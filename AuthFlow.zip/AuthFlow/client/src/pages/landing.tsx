import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building, Users, TrendingUp, Shield, Clock, FileText } from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Users,
      title: "Employee Management",
      description: "Comprehensive employee profiles with advanced filtering and CRUD operations"
    },
    {
      icon: FileText,
      title: "Document Management",
      description: "Secure document storage with real-time tracking and automated reminders"
    },
    {
      icon: TrendingUp,
      title: "Performance Analytics",
      description: "KPI tracking with automated evaluations and visual performance insights"
    },
    {
      icon: Clock,
      title: "Time & Attendance",
      description: "Real-time check-in/out system with automated hour calculations"
    },
    {
      icon: Shield,
      title: "Role-based Security",
      description: "Enterprise-grade security with granular access controls and permissions"
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary via-primary/90 to-slate-900">
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="mx-auto w-20 h-20 bg-accent rounded-full flex items-center justify-center mb-6">
            <Building className="h-10 w-10 text-accent-foreground" />
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            HRIS System
          </h1>
          
          <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            A comprehensive Human Resources Information System designed for modern enterprises. 
            Streamline HR operations, track performance, and manage your workforce with real-time insights.
          </p>

          <Button
            size="lg"
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-8 py-3 text-lg"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-login"
          >
            Access Dashboard
            <motion.div
              initial={{ x: 0 }}
              animate={{ x: [0, 4, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
              className="ml-2"
            >
              →
            </motion.div>
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16"
        >
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
            >
              <Card className="h-full bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/15 transition-all duration-300">
                <CardContent className="p-6">
                  <feature.icon className="h-12 w-12 text-accent mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
                  <p className="text-white/70">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center"
        >
          <Card className="max-w-4xl mx-auto bg-white/5 backdrop-blur-sm border-white/20">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-white mb-6">Enterprise-Ready Features</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-accent mb-2">99.9%</div>
                  <div className="text-white/70">System Uptime</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-accent mb-2">24/7</div>
                  <div className="text-white/70">Real-time Monitoring</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-accent mb-2">256-bit</div>
                  <div className="text-white/70">Data Encryption</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
