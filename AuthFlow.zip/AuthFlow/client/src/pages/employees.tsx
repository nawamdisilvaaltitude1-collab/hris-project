import { motion } from "framer-motion";
import EmployeeFilters from "@/components/employees/employee-filters";
import EmployeeTable from "@/components/employees/employee-table";

export default function Employees() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <EmployeeFilters />
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <EmployeeTable />
      </motion.div>
    </motion.div>
  );
}
