import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useState } from "react";
import { 
  CloudUpload, 
  UserPlus, 
  Calendar, 
  FileText, 
  Download, 
  Link as LinkIcon, 
  Users, 
  Eye,
  MessageSquare,
  BarChart3,
  FileUp
} from "lucide-react";

export default function Recruitment() {
  const [newCandidate, setNewCandidate] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    positionApplied: "",
    cvUrl: "",
    cvFileName: "",
    stage: "application",
    notes: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: candidates = [], isLoading } = useQuery({
    queryKey: ["/api/candidates"],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    }
  });

  const createCandidateMutation = useMutation({
    mutationFn: async (candidate: typeof newCandidate) => {
      return await apiRequest("POST", "/api/candidates", candidate);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidates"] });
      setNewCandidate({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        positionApplied: "",
        cvUrl: "",
        cvFileName: "",
        stage: "application",
        notes: ""
      });
      toast({
        title: "Success",
        description: "Candidate added successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add candidate",
        variant: "destructive",
      });
    },
  });

  const updateCandidateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: any }) => {
      return await apiRequest("PATCH", `/api/candidates/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidates"] });
      toast({
        title: "Success",
        description: "Candidate updated successfully",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update candidate",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCandidate.firstName || !newCandidate.lastName || !newCandidate.email || !newCandidate.positionApplied) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    createCandidateMutation.mutate(newCandidate);
  };

  const handleStageChange = (candidateId: string, newStage: string) => {
    updateCandidateMutation.mutate({
      id: candidateId,
      updates: { stage: newStage }
    });
  };

  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'application':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'screening':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'interview':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      case 'final_review':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'hired':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'rejected':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const pipelineStats = {
    applications: candidates.filter(c => c.stage === 'application').length,
    screening: candidates.filter(c => c.stage === 'screening').length,
    interview: candidates.filter(c => c.stage === 'interview').length,
    hired: candidates.filter(c => c.stage === 'hired').length,
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Add New Candidate</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">First Name *</label>
                    <Input
                      type="text"
                      placeholder="John"
                      value={newCandidate.firstName}
                      onChange={(e) => setNewCandidate(prev => ({ ...prev, firstName: e.target.value }))}
                      data-testid="input-first-name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Last Name *</label>
                    <Input
                      type="text"
                      placeholder="Doe"
                      value={newCandidate.lastName}
                      onChange={(e) => setNewCandidate(prev => ({ ...prev, lastName: e.target.value }))}
                      data-testid="input-last-name"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Email *</label>
                  <Input
                    type="email"
                    placeholder="john.doe@email.com"
                    value={newCandidate.email}
                    onChange={(e) => setNewCandidate(prev => ({ ...prev, email: e.target.value }))}
                    data-testid="input-email"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Phone</label>
                  <Input
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={newCandidate.phone}
                    onChange={(e) => setNewCandidate(prev => ({ ...prev, phone: e.target.value }))}
                    data-testid="input-phone"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Position Applied *</label>
                  <Select 
                    value={newCandidate.positionApplied} 
                    onValueChange={(value) => setNewCandidate(prev => ({ ...prev, positionApplied: value }))}
                  >
                    <SelectTrigger data-testid="select-position">
                      <SelectValue placeholder="Select Position" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="software_engineer">Software Engineer</SelectItem>
                      <SelectItem value="marketing_manager">Marketing Manager</SelectItem>
                      <SelectItem value="sales_representative">Sales Representative</SelectItem>
                      <SelectItem value="hr_specialist">HR Specialist</SelectItem>
                      <SelectItem value="data_analyst">Data Analyst</SelectItem>
                      <SelectItem value="product_manager">Product Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">CV/Resume</label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                    <CloudUpload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground mb-2">Upload CV or provide link</p>
                    <div className="flex space-x-2">
                      <Button type="button" size="sm" variant="outline" data-testid="button-upload-file">
                        <FileUp className="h-4 w-4 mr-1" />
                        Upload File
                      </Button>
                      <Input
                        type="url"
                        className="flex-1"
                        placeholder="Or paste CV link..."
                        value={newCandidate.cvUrl}
                        onChange={(e) => setNewCandidate(prev => ({ ...prev, cvUrl: e.target.value }))}
                        data-testid="input-cv-url"
                      />
                    </div>
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={createCandidateMutation.isPending}
                  data-testid="button-add-candidate"
                >
                  {createCandidateMutation.isPending ? (
                    <>Adding...</>
                  ) : (
                    <>
                      <UserPlus className="mr-2 h-4 w-4" />
                      Add Candidate
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
        
        <div className="space-y-6">
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Recruitment Pipeline</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.3 }}
                  className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg"
                >
                  <div>
                    <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Applications</p>
                    <p className="text-xs text-blue-600 dark:text-blue-400">Total received</p>
                  </div>
                  <span className="text-xl font-bold text-blue-900 dark:text-blue-100" data-testid="stat-applications">
                    {pipelineStats.applications}
                  </span>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.4 }}
                  className="flex items-center justify-between p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg"
                >
                  <div>
                    <p className="text-sm font-medium text-yellow-800 dark:text-yellow-300">Screening</p>
                    <p className="text-xs text-yellow-600 dark:text-yellow-400">Under review</p>
                  </div>
                  <span className="text-xl font-bold text-yellow-900 dark:text-yellow-100" data-testid="stat-screening">
                    {pipelineStats.screening}
                  </span>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.5 }}
                  className="flex items-center justify-between p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg"
                >
                  <div>
                    <p className="text-sm font-medium text-purple-800 dark:text-purple-300">Interview</p>
                    <p className="text-xs text-purple-600 dark:text-purple-400">Scheduled</p>
                  </div>
                  <span className="text-xl font-bold text-purple-900 dark:text-purple-100" data-testid="stat-interview">
                    {pipelineStats.interview}
                  </span>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: 0.6 }}
                  className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg"
                >
                  <div>
                    <p className="text-sm font-medium text-green-800 dark:text-green-300">Hired</p>
                    <p className="text-xs text-green-600 dark:text-green-400">This month</p>
                  </div>
                  <span className="text-xl font-bold text-green-900 dark:text-green-100" data-testid="stat-hired">
                    {pipelineStats.hired}
                  </span>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
          
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  data-testid="button-schedule-interview"
                >
                  <Calendar className="mr-3 h-4 w-4 text-blue-600" />
                  Schedule Interview
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  data-testid="button-export-reports"
                >
                  <BarChart3 className="mr-3 h-4 w-4 text-green-600" />
                  Export Reports
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  data-testid="button-bulk-actions"
                >
                  <Users className="mr-3 h-4 w-4 text-purple-600" />
                  Bulk Actions
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Candidate Management</CardTitle>
            <div className="flex items-center space-x-4">
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Stages" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Stages</SelectItem>
                  <SelectItem value="application">Application</SelectItem>
                  <SelectItem value="screening">Screening</SelectItem>
                  <SelectItem value="interview">Interview</SelectItem>
                  <SelectItem value="final_review">Final Review</SelectItem>
                </SelectContent>
              </Select>
              <Select>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Positions" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Positions</SelectItem>
                  <SelectItem value="software_engineer">Software Engineer</SelectItem>
                  <SelectItem value="marketing_manager">Marketing Manager</SelectItem>
                  <SelectItem value="sales_representative">Sales Representative</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Candidate</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>Stage</TableHead>
                    <TableHead>Applied Date</TableHead>
                    <TableHead>CV/Resume</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="animate-pulse">Loading candidates...</div>
                      </TableCell>
                    </TableRow>
                  ) : candidates.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        <div className="flex flex-col items-center">
                          <Users className="h-12 w-12 text-muted-foreground mb-4" />
                          <p className="text-muted-foreground">No candidates found</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : (
                    candidates.map((candidate: any, index: number) => (
                      <motion.tr
                        key={candidate.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="hover:bg-muted/50 transition-colors"
                      >
                        <TableCell>
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center mr-3">
                              <span className="text-sm font-bold text-accent-foreground">
                                {(candidate.firstName?.[0] || '') + (candidate.lastName?.[0] || '')}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium">{candidate.firstName} {candidate.lastName}</p>
                              <p className="text-sm text-muted-foreground">{candidate.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="capitalize">
                          {candidate.positionApplied?.replace('_', ' ') || 'Not specified'}
                        </TableCell>
                        <TableCell>
                          <Badge className={getStageColor(candidate.stage)}>
                            {candidate.stage?.replace('_', ' ') || 'Application'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {candidate.appliedDate ? new Date(candidate.appliedDate).toLocaleDateString() : 'N/A'}
                        </TableCell>
                        <TableCell>
                          {candidate.cvUrl ? (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-blue-600 hover:text-blue-800"
                              data-testid={`button-view-cv-${candidate.id}`}
                            >
                              {candidate.cvUrl.includes('linkedin') ? (
                                <>
                                  <LinkIcon className="h-4 w-4 mr-2" />
                                  <span>LinkedIn</span>
                                </>
                              ) : (
                                <>
                                  <FileText className="h-4 w-4 mr-2" />
                                  <span>View CV</span>
                                </>
                              )}
                            </Button>
                          ) : (
                            <span className="text-muted-foreground">No CV</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Select
                              value={candidate.stage}
                              onValueChange={(value) => handleStageChange(candidate.id, value)}
                            >
                              <SelectTrigger className="w-32 h-8 text-xs" data-testid={`select-stage-${candidate.id}`}>
                                <SelectValue placeholder="Move to..." />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="application">Application</SelectItem>
                                <SelectItem value="screening">Screening</SelectItem>
                                <SelectItem value="interview">Interview</SelectItem>
                                <SelectItem value="final_review">Final Review</SelectItem>
                                <SelectItem value="hired">Hired</SelectItem>
                                <SelectItem value="rejected">Rejected</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              data-testid={`button-schedule-${candidate.id}`}
                            >
                              <Calendar className="h-4 w-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              data-testid={`button-comment-${candidate.id}`}
                            >
                              <MessageSquare className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </motion.tr>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
