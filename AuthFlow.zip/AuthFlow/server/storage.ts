import {
  users,
  employees,
  documents,
  performanceRecords,
  leaveRequests,
  leaveBalances,
  attendanceRecords,
  candidates,
  type User,
  type UpsertUser,
  type Employee,
  type InsertEmployee,
  type Document,
  type InsertDocument,
  type PerformanceRecord,
  type InsertPerformanceRecord,
  type LeaveRequest,
  type InsertLeaveRequest,
  type LeaveBalance,
  type InsertLeaveBalance,
  type AttendanceRecord,
  type InsertAttendanceRecord,
  type Candidate,
  type InsertCandidate,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql, count } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Employee operations
  getEmployees(): Promise<Employee[]>;
  getEmployee(id: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: string, employee: Partial<InsertEmployee>): Promise<Employee>;
  deleteEmployee(id: string): Promise<void>;
  getEmployeesByDepartment(department: string): Promise<Employee[]>;
  
  // Document operations
  getDocuments(): Promise<Document[]>;
  getDocumentsByEmployee(employeeId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: string, document: Partial<InsertDocument>): Promise<Document>;
  deleteDocument(id: string): Promise<void>;
  
  // Performance operations
  getPerformanceRecords(): Promise<PerformanceRecord[]>;
  getPerformanceRecordsByEmployee(employeeId: string): Promise<PerformanceRecord[]>;
  createPerformanceRecord(record: InsertPerformanceRecord): Promise<PerformanceRecord>;
  updatePerformanceRecord(id: string, record: Partial<InsertPerformanceRecord>): Promise<PerformanceRecord>;
  
  // Leave operations
  getLeaveRequests(): Promise<LeaveRequest[]>;
  getLeaveRequestsByEmployee(employeeId: string): Promise<LeaveRequest[]>;
  createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest>;
  updateLeaveRequest(id: string, request: Partial<InsertLeaveRequest>): Promise<LeaveRequest>;
  getLeaveBalances(employeeId: string): Promise<LeaveBalance[]>;
  createLeaveBalance(balance: InsertLeaveBalance): Promise<LeaveBalance>;
  updateLeaveBalance(id: string, balance: Partial<InsertLeaveBalance>): Promise<LeaveBalance>;
  
  // Attendance operations
  getAttendanceRecords(): Promise<AttendanceRecord[]>;
  getAttendanceRecordsByEmployee(employeeId: string): Promise<AttendanceRecord[]>;
  createAttendanceRecord(record: InsertAttendanceRecord): Promise<AttendanceRecord>;
  updateAttendanceRecord(id: string, record: Partial<InsertAttendanceRecord>): Promise<AttendanceRecord>;
  getTodayAttendance(employeeId: string): Promise<AttendanceRecord | undefined>;
  
  // Candidate operations
  getCandidates(): Promise<Candidate[]>;
  createCandidate(candidate: InsertCandidate): Promise<Candidate>;
  updateCandidate(id: string, candidate: Partial<InsertCandidate>): Promise<Candidate>;
  deleteCandidate(id: string): Promise<void>;
  
  // Dashboard metrics
  getDashboardMetrics(): Promise<{
    totalEmployees: number;
    activeLeaves: number;
    topPerformers: number;
    pendingRequests: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Employee operations
  async getEmployees(): Promise<Employee[]> {
    return await db.select().from(employees).orderBy(desc(employees.createdAt));
  }

  async getEmployee(id: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee;
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const [newEmployee] = await db.insert(employees).values(employee).returning();
    return newEmployee;
  }

  async updateEmployee(id: string, employee: Partial<InsertEmployee>): Promise<Employee> {
    const [updatedEmployee] = await db
      .update(employees)
      .set({ ...employee, updatedAt: new Date() })
      .where(eq(employees.id, id))
      .returning();
    return updatedEmployee;
  }

  async deleteEmployee(id: string): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  async getEmployeesByDepartment(department: string): Promise<Employee[]> {
    return await db.select().from(employees).where(eq(employees.department, department));
  }

  // Document operations
  async getDocuments(): Promise<Document[]> {
    return await db.select().from(documents).orderBy(desc(documents.uploadDate));
  }

  async getDocumentsByEmployee(employeeId: string): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.employeeId, employeeId));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db.insert(documents).values(document).returning();
    return newDocument;
  }

  async updateDocument(id: string, document: Partial<InsertDocument>): Promise<Document> {
    const [updatedDocument] = await db
      .update(documents)
      .set(document)
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  async deleteDocument(id: string): Promise<void> {
    await db.delete(documents).where(eq(documents.id, id));
  }

  // Performance operations
  async getPerformanceRecords(): Promise<PerformanceRecord[]> {
    return await db.select().from(performanceRecords).orderBy(desc(performanceRecords.createdAt));
  }

  async getPerformanceRecordsByEmployee(employeeId: string): Promise<PerformanceRecord[]> {
    return await db
      .select()
      .from(performanceRecords)
      .where(eq(performanceRecords.employeeId, employeeId))
      .orderBy(desc(performanceRecords.month));
  }

  async createPerformanceRecord(record: InsertPerformanceRecord): Promise<PerformanceRecord> {
    const [newRecord] = await db.insert(performanceRecords).values(record).returning();
    return newRecord;
  }

  async updatePerformanceRecord(id: string, record: Partial<InsertPerformanceRecord>): Promise<PerformanceRecord> {
    const [updatedRecord] = await db
      .update(performanceRecords)
      .set({ ...record, updatedAt: new Date() })
      .where(eq(performanceRecords.id, id))
      .returning();
    return updatedRecord;
  }

  // Leave operations
  async getLeaveRequests(): Promise<LeaveRequest[]> {
    return await db.select().from(leaveRequests).orderBy(desc(leaveRequests.createdAt));
  }

  async getLeaveRequestsByEmployee(employeeId: string): Promise<LeaveRequest[]> {
    return await db
      .select()
      .from(leaveRequests)
      .where(eq(leaveRequests.employeeId, employeeId))
      .orderBy(desc(leaveRequests.createdAt));
  }

  async createLeaveRequest(request: InsertLeaveRequest): Promise<LeaveRequest> {
    const [newRequest] = await db.insert(leaveRequests).values(request).returning();
    return newRequest;
  }

  async updateLeaveRequest(id: string, request: Partial<InsertLeaveRequest>): Promise<LeaveRequest> {
    const [updatedRequest] = await db
      .update(leaveRequests)
      .set({ ...request, updatedAt: new Date() })
      .where(eq(leaveRequests.id, id))
      .returning();
    return updatedRequest;
  }

  async getLeaveBalances(employeeId: string): Promise<LeaveBalance[]> {
    return await db.select().from(leaveBalances).where(eq(leaveBalances.employeeId, employeeId));
  }

  async createLeaveBalance(balance: InsertLeaveBalance): Promise<LeaveBalance> {
    const [newBalance] = await db.insert(leaveBalances).values(balance).returning();
    return newBalance;
  }

  async updateLeaveBalance(id: string, balance: Partial<InsertLeaveBalance>): Promise<LeaveBalance> {
    const [updatedBalance] = await db
      .update(leaveBalances)
      .set(balance)
      .where(eq(leaveBalances.id, id))
      .returning();
    return updatedBalance;
  }

  // Attendance operations
  async getAttendanceRecords(): Promise<AttendanceRecord[]> {
    return await db.select().from(attendanceRecords).orderBy(desc(attendanceRecords.date));
  }

  async getAttendanceRecordsByEmployee(employeeId: string): Promise<AttendanceRecord[]> {
    return await db
      .select()
      .from(attendanceRecords)
      .where(eq(attendanceRecords.employeeId, employeeId))
      .orderBy(desc(attendanceRecords.date));
  }

  async createAttendanceRecord(record: InsertAttendanceRecord): Promise<AttendanceRecord> {
    const [newRecord] = await db.insert(attendanceRecords).values(record).returning();
    return newRecord;
  }

  async updateAttendanceRecord(id: string, record: Partial<InsertAttendanceRecord>): Promise<AttendanceRecord> {
    const [updatedRecord] = await db
      .update(attendanceRecords)
      .set(record)
      .where(eq(attendanceRecords.id, id))
      .returning();
    return updatedRecord;
  }

  async getTodayAttendance(employeeId: string): Promise<AttendanceRecord | undefined> {
    const today = new Date().toISOString().split('T')[0];
    const [record] = await db
      .select()
      .from(attendanceRecords)
      .where(and(
        eq(attendanceRecords.employeeId, employeeId),
        eq(attendanceRecords.date, today)
      ));
    return record;
  }

  // Candidate operations
  async getCandidates(): Promise<Candidate[]> {
    return await db.select().from(candidates).orderBy(desc(candidates.appliedDate));
  }

  async createCandidate(candidate: InsertCandidate): Promise<Candidate> {
    const [newCandidate] = await db.insert(candidates).values(candidate).returning();
    return newCandidate;
  }

  async updateCandidate(id: string, candidate: Partial<InsertCandidate>): Promise<Candidate> {
    const [updatedCandidate] = await db
      .update(candidates)
      .set({ ...candidate, updatedAt: new Date() })
      .where(eq(candidates.id, id))
      .returning();
    return updatedCandidate;
  }

  async deleteCandidate(id: string): Promise<void> {
    await db.delete(candidates).where(eq(candidates.id, id));
  }

  // Dashboard metrics
  async getDashboardMetrics(): Promise<{
    totalEmployees: number;
    activeLeaves: number;
    topPerformers: number;
    pendingRequests: number;
  }> {
    const [totalEmployeesResult] = await db.select({ count: count() }).from(employees);
    const [activeLeavesResult] = await db.select({ count: count() }).from(leaveRequests).where(eq(leaveRequests.status, 'approved'));
    const [topPerformersResult] = await db.select({ count: count() }).from(performanceRecords).where(gte(performanceRecords.kpiScore, '60'));
    const [pendingRequestsResult] = await db.select({ count: count() }).from(leaveRequests).where(eq(leaveRequests.status, 'pending'));

    return {
      totalEmployees: totalEmployeesResult.count,
      activeLeaves: activeLeavesResult.count,
      topPerformers: topPerformersResult.count,
      pendingRequests: pendingRequestsResult.count,
    };
  }
}

export const storage = new DatabaseStorage();
