import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertEmployeeSchema, insertDocumentSchema, insertPerformanceRecordSchema, insertLeaveRequestSchema, insertAttendanceRecordSchema, insertCandidateSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard routes
  app.get("/api/dashboard/metrics", isAuthenticated, async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Employee routes
  app.get("/api/employees", isAuthenticated, async (req, res) => {
    try {
      const employees = await storage.getEmployees();
      res.json(employees);
    } catch (error) {
      console.error("Error fetching employees:", error);
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  app.get("/api/employees/:id", isAuthenticated, async (req, res) => {
    try {
      const employee = await storage.getEmployee(req.params.id);
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.json(employee);
    } catch (error) {
      console.error("Error fetching employee:", error);
      res.status(500).json({ message: "Failed to fetch employee" });
    }
  });

  app.post("/api/employees", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertEmployeeSchema.parse(req.body);
      const employee = await storage.createEmployee(validatedData);
      res.status(201).json(employee);
    } catch (error) {
      console.error("Error creating employee:", error);
      res.status(400).json({ message: "Failed to create employee" });
    }
  });

  app.patch("/api/employees/:id", isAuthenticated, async (req, res) => {
    try {
      const employee = await storage.updateEmployee(req.params.id, req.body);
      res.json(employee);
    } catch (error) {
      console.error("Error updating employee:", error);
      res.status(400).json({ message: "Failed to update employee" });
    }
  });

  app.delete("/api/employees/:id", isAuthenticated, async (req, res) => {
    try {
      await storage.deleteEmployee(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting employee:", error);
      res.status(400).json({ message: "Failed to delete employee" });
    }
  });

  // Document routes
  app.get("/api/documents", isAuthenticated, async (req, res) => {
    try {
      const documents = await storage.getDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.get("/api/documents/employee/:employeeId", isAuthenticated, async (req, res) => {
    try {
      const documents = await storage.getDocumentsByEmployee(req.params.employeeId);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching employee documents:", error);
      res.status(500).json({ message: "Failed to fetch employee documents" });
    }
  });

  app.post("/api/documents", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertDocumentSchema.parse(req.body);
      const document = await storage.createDocument(validatedData);
      res.status(201).json(document);
    } catch (error) {
      console.error("Error creating document:", error);
      res.status(400).json({ message: "Failed to create document" });
    }
  });

  app.patch("/api/documents/:id", isAuthenticated, async (req, res) => {
    try {
      const document = await storage.updateDocument(req.params.id, req.body);
      res.json(document);
    } catch (error) {
      console.error("Error updating document:", error);
      res.status(400).json({ message: "Failed to update document" });
    }
  });

  // Performance routes
  app.get("/api/performance", isAuthenticated, async (req, res) => {
    try {
      const records = await storage.getPerformanceRecords();
      res.json(records);
    } catch (error) {
      console.error("Error fetching performance records:", error);
      res.status(500).json({ message: "Failed to fetch performance records" });
    }
  });

  app.get("/api/performance/employee/:employeeId", isAuthenticated, async (req, res) => {
    try {
      const records = await storage.getPerformanceRecordsByEmployee(req.params.employeeId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching employee performance:", error);
      res.status(500).json({ message: "Failed to fetch employee performance" });
    }
  });

  app.post("/api/performance", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertPerformanceRecordSchema.parse(req.body);
      // Auto-categorize based on KPI score
      const category = parseFloat(validatedData.kpiScore) >= 60 ? "performer" : "needs_improvement";
      const recordWithCategory = { ...validatedData, category };
      const record = await storage.createPerformanceRecord(recordWithCategory);
      res.status(201).json(record);
    } catch (error) {
      console.error("Error creating performance record:", error);
      res.status(400).json({ message: "Failed to create performance record" });
    }
  });

  // Leave routes
  app.get("/api/leave/requests", isAuthenticated, async (req, res) => {
    try {
      const requests = await storage.getLeaveRequests();
      res.json(requests);
    } catch (error) {
      console.error("Error fetching leave requests:", error);
      res.status(500).json({ message: "Failed to fetch leave requests" });
    }
  });

  app.get("/api/leave/requests/employee/:employeeId", isAuthenticated, async (req, res) => {
    try {
      const requests = await storage.getLeaveRequestsByEmployee(req.params.employeeId);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching employee leave requests:", error);
      res.status(500).json({ message: "Failed to fetch employee leave requests" });
    }
  });

  app.post("/api/leave/requests", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertLeaveRequestSchema.parse(req.body);
      const request = await storage.createLeaveRequest(validatedData);
      res.status(201).json(request);
    } catch (error) {
      console.error("Error creating leave request:", error);
      res.status(400).json({ message: "Failed to create leave request" });
    }
  });

  app.patch("/api/leave/requests/:id", isAuthenticated, async (req: any, res) => {
    try {
      const updateData = req.body;
      if (updateData.status === 'approved' || updateData.status === 'rejected') {
        updateData.approvedBy = req.user.claims.sub;
        updateData.approvedAt = new Date();
      }
      const request = await storage.updateLeaveRequest(req.params.id, updateData);
      res.json(request);
    } catch (error) {
      console.error("Error updating leave request:", error);
      res.status(400).json({ message: "Failed to update leave request" });
    }
  });

  app.get("/api/leave/balances/:employeeId", isAuthenticated, async (req, res) => {
    try {
      const balances = await storage.getLeaveBalances(req.params.employeeId);
      res.json(balances);
    } catch (error) {
      console.error("Error fetching leave balances:", error);
      res.status(500).json({ message: "Failed to fetch leave balances" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const records = await storage.getAttendanceRecords();
      res.json(records);
    } catch (error) {
      console.error("Error fetching attendance records:", error);
      res.status(500).json({ message: "Failed to fetch attendance records" });
    }
  });

  app.get("/api/attendance/employee/:employeeId", isAuthenticated, async (req, res) => {
    try {
      const records = await storage.getAttendanceRecordsByEmployee(req.params.employeeId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching employee attendance:", error);
      res.status(500).json({ message: "Failed to fetch employee attendance" });
    }
  });

  app.get("/api/attendance/today/:employeeId", isAuthenticated, async (req, res) => {
    try {
      const record = await storage.getTodayAttendance(req.params.employeeId);
      res.json(record);
    } catch (error) {
      console.error("Error fetching today's attendance:", error);
      res.status(500).json({ message: "Failed to fetch today's attendance" });
    }
  });

  app.post("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertAttendanceRecordSchema.parse(req.body);
      const record = await storage.createAttendanceRecord(validatedData);
      res.status(201).json(record);
    } catch (error) {
      console.error("Error creating attendance record:", error);
      res.status(400).json({ message: "Failed to create attendance record" });
    }
  });

  app.patch("/api/attendance/:id", isAuthenticated, async (req, res) => {
    try {
      const record = await storage.updateAttendanceRecord(req.params.id, req.body);
      res.json(record);
    } catch (error) {
      console.error("Error updating attendance record:", error);
      res.status(400).json({ message: "Failed to update attendance record" });
    }
  });

  // Candidate routes
  app.get("/api/candidates", isAuthenticated, async (req, res) => {
    try {
      const candidates = await storage.getCandidates();
      res.json(candidates);
    } catch (error) {
      console.error("Error fetching candidates:", error);
      res.status(500).json({ message: "Failed to fetch candidates" });
    }
  });

  app.post("/api/candidates", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertCandidateSchema.parse(req.body);
      const candidate = await storage.createCandidate(validatedData);
      res.status(201).json(candidate);
    } catch (error) {
      console.error("Error creating candidate:", error);
      res.status(400).json({ message: "Failed to create candidate" });
    }
  });

  app.patch("/api/candidates/:id", isAuthenticated, async (req, res) => {
    try {
      const candidate = await storage.updateCandidate(req.params.id, req.body);
      res.json(candidate);
    } catch (error) {
      console.error("Error updating candidate:", error);
      res.status(400).json({ message: "Failed to update candidate" });
    }
  });

  app.delete("/api/candidates/:id", isAuthenticated, async (req, res) => {
    try {
      await storage.deleteCandidate(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting candidate:", error);
      res.status(400).json({ message: "Failed to delete candidate" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
